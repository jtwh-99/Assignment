﻿Imports System.Data.DataTable
Public Class MakeOrders

    Dim table As New DataTable("table")

    Sub Validation()
        If numRose.Value = 0 And numOrchid.Value = 0 And numLily.Value = 0 Then
            ErrorProvider1.SetError(numLily, "Please enter at least one item!")
            ErrorProvider1.SetError(numOrchid, "Please enter at least one item!")
            ErrorProvider1.SetError(numRose, "Please enter at least one item!")
        End If

        If radPickUp.Checked = True Then
            If txtTime.Text = "" Then
                ErrorProvider1.SetError(txtTime, "Please enter the time")
            End If
        ElseIf radDelivery.Checked = True Then
            If txtAddress.Text = "" Then
                ErrorProvider1.SetError(txtAddress, "Please enter the address")
            End If
        End If
    End Sub

    Private Sub btnOrder_Click(sender As Object, e As EventArgs) Handles btnOrder.Click

        If ErrorProvider1.GetError(numLily) = "" Then
            Dim rn As New Random
            If radCashOnDelivery.Checked = True And radPickUp.Checked = True Then

                table.Rows.Add(rn.Next(1000, 9999), numRose.Value, numOrchid.Value, numLily.Value, radCashOnDelivery.Text, radPickUp.Text, lblTotalPrice.Text)

            ElseIf radCashOnDelivery.Checked = True And radPickUp.Checked = False Then

                table.Rows.Add(rn.Next(1000, 9999), numRose.Value, numOrchid.Value, numLily.Value, radCashOnDelivery.Text, radDelivery.Text, lblTotalPrice.Text)

            ElseIf radCashOnDelivery.Checked = False And radPickUp.Checked = True Then

                table.Rows.Add(rn.Next(1000, 9999), numRose.Value, numOrchid.Value, numLily.Value, radCashOnPickUp.Text, radPickUp.Text, lblTotalPrice.Text)

            ElseIf radCashOnDelivery.Checked = False And radPickUp.Checked = False Then

                table.Rows.Add(rn.Next(1000, 9999), numRose.Value, numOrchid.Value, numLily.Value, radCashOnPickUp.Text, radDelivery.Text, lblTotalPrice.Text)
            End If


            MessageBox.Show("Your Order Have Been Placed.")

            numLily.Value = 0
            numOrchid.Value = 0
            numRose.Value = 0
            txtTime.Text = ""
            txtAddress.Text = ""
            lblTotalPrice.Text = ""
            radPickUp.Checked = True
            radCashOnDelivery.Checked = True

        Else
            Validation()
        End If



        'Dim result As DialogResult = MessageBox.Show("Confirm Your Order?", "Confirm Order", MessageBoxButtons.YesNo)
        'If result = DialogResult.OK Then

        'Else

        'End If
    End Sub

    Private Sub radPickUp_CheckedChanged(sender As Object, e As EventArgs) Handles radPickUp.CheckedChanged
        If radPickUp.Checked Then
            GroupBox4.Enabled = False
            GroupBox3.Enabled = True
        End If
    End Sub

    Private Sub radDelivery_CheckedChanged(sender As Object, e As EventArgs) Handles radDelivery.CheckedChanged
        If radDelivery.Checked Then
            GroupBox3.Enabled = False
            GroupBox4.Enabled = True
        End If
    End Sub

    Private Sub MakeOrders_Load(sender As Object, e As EventArgs) Handles Me.Load

        numLily.Value = 0
        numOrchid.Value = 0
        numRose.Value = 0
        txtTime.Text = ""
        txtAddress.Text = ""
        lblTotalPrice.Text = ""
        radPickUp.Checked = True
        radCashOnDelivery.Checked = True

        table.Columns.Add("ID", Type.GetType("System.Int32"))
        table.Columns.Add("Rose", Type.GetType("System.Int32"))
        table.Columns.Add("Orchid", Type.GetType("System.Int32"))
        table.Columns.Add("Lily", Type.GetType("System.Int32"))
        table.Columns.Add("PaymentMethod", Type.GetType("System.String"))
        table.Columns.Add("DeliveryMethod", Type.GetType("System.String"))
        table.Columns.Add("Total Price", Type.GetType("System.Int32"))

        DataGridView1.DataSource = table
    End Sub

    Private Sub numRose_ValueChanged(sender As Object, e As EventArgs) Handles numRose.ValueChanged
        lblTotalPrice.Text = (numLily.Value + numOrchid.Value + numRose.Value) * 10

    End Sub

    Private Sub numOrchid_ValueChanged(sender As Object, e As EventArgs) Handles numOrchid.ValueChanged
        lblTotalPrice.Text = (numLily.Value + numOrchid.Value + numRose.Value) * 10

    End Sub

    Private Sub numLily_ValueChanged(sender As Object, e As EventArgs) Handles numLily.ValueChanged
        lblTotalPrice.Text = (numLily.Value + numOrchid.Value + numRose.Value) * 10

    End Sub

    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Me.Close()
        Form1.Show()
    End Sub
End Class