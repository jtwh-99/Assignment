﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SalesOrder
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvSalesOrder = New System.Windows.Forms.DataGridView()
        Me.btnBack = New System.Windows.Forms.Button()
        CType(Me.dgvSalesOrder, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvSalesOrder
        '
        Me.dgvSalesOrder.AllowUserToAddRows = False
        Me.dgvSalesOrder.AllowUserToDeleteRows = False
        Me.dgvSalesOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvSalesOrder.Location = New System.Drawing.Point(34, 61)
        Me.dgvSalesOrder.Name = "dgvSalesOrder"
        Me.dgvSalesOrder.ReadOnly = True
        Me.dgvSalesOrder.RowHeadersWidth = 51
        Me.dgvSalesOrder.RowTemplate.Height = 24
        Me.dgvSalesOrder.Size = New System.Drawing.Size(1007, 399)
        Me.dgvSalesOrder.TabIndex = 0
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.Location = New System.Drawing.Point(34, 12)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(172, 37)
        Me.btnBack.TabIndex = 1
        Me.btnBack.Text = "Back to Main Menu"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'SalesOrder
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1072, 483)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.dgvSalesOrder)
        Me.Name = "SalesOrder"
        Me.Text = "SalesOrder"
        CType(Me.dgvSalesOrder, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvSalesOrder As DataGridView
    Friend WithEvents btnBack As Button
End Class
