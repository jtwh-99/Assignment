﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Flower = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.textResult = New System.Windows.Forms.RichTextBox()
        Me.SuspendLayout()
        '
        'Flower
        '
        Me.Flower.Location = New System.Drawing.Point(33, 33)
        Me.Flower.Name = "Flower"
        Me.Flower.Size = New System.Drawing.Size(72, 23)
        Me.Flower.TabIndex = 0
        Me.Flower.Text = "Flower: "
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"Aconitum (RM 10)", "Echinacea (RM 15)", "Iberis (RM 5)", "Rain Lily (RM 10)"})
        Me.ComboBox1.Location = New System.Drawing.Point(111, 33)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(141, 24)
        Me.ComboBox1.TabIndex = 1
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(102, 113)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(88, 44)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "Generate Receipt"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'textResult
        '
        Me.textResult.Location = New System.Drawing.Point(290, 30)
        Me.textResult.Name = "textResult"
        Me.textResult.Size = New System.Drawing.Size(250, 196)
        Me.textResult.TabIndex = 3
        Me.textResult.Text = ""
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(565, 247)
        Me.Controls.Add(Me.textResult)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Flower)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Flower As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Button1 As Button
    Friend WithEvents textResult As RichTextBox
End Class
