﻿Public Class Form1
    Private Sub Flower_Click(sender As Object, e As EventArgs) Handles Flower.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ComboBox1.SelectedIndex = -1 Then
            MessageBox.Show("Please select flower!")

        Else
            textResult.Text = "***********************" + Environment.NewLine + "**       Receipt        **" +
         Environment.NewLine + "***********************" + Environment.NewLine + "Date: " + DateAndTime.Now + Environment.NewLine +
         Environment.NewLine + Environment.NewLine + "Price: " + ComboBox1.SelectedItem
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
