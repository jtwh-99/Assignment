﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PayBill
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtDate = New System.Windows.Forms.Label()
        Me.txtGrand = New System.Windows.Forms.Label()
        Me.txtTax = New System.Windows.Forms.Label()
        Me.richTxtDescrip = New System.Windows.Forms.RichTextBox()
        Me.btnPay = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtMoney = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(43, 36)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 24)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Invoice : "
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"1001", "1002", "1003"})
        Me.ComboBox1.Location = New System.Drawing.Point(109, 33)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(147, 24)
        Me.ComboBox1.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(54, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 17)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Description: "
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(504, 112)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(46, 17)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Date: "
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(504, 199)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(127, 17)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Grand Total (RM): "
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(504, 158)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 17)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Tax: "
        '
        'txtDate
        '
        Me.txtDate.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtDate.Location = New System.Drawing.Point(638, 109)
        Me.txtDate.Name = "txtDate"
        Me.txtDate.Size = New System.Drawing.Size(104, 26)
        Me.txtDate.TabIndex = 13
        '
        'txtGrand
        '
        Me.txtGrand.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtGrand.Location = New System.Drawing.Point(638, 196)
        Me.txtGrand.Name = "txtGrand"
        Me.txtGrand.Size = New System.Drawing.Size(104, 24)
        Me.txtGrand.TabIndex = 14
        '
        'txtTax
        '
        Me.txtTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.txtTax.Location = New System.Drawing.Point(638, 155)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.Size = New System.Drawing.Size(104, 23)
        Me.txtTax.TabIndex = 15
        '
        'richTxtDescrip
        '
        Me.richTxtDescrip.Location = New System.Drawing.Point(147, 109)
        Me.richTxtDescrip.Name = "richTxtDescrip"
        Me.richTxtDescrip.Size = New System.Drawing.Size(338, 136)
        Me.richTxtDescrip.TabIndex = 16
        Me.richTxtDescrip.Text = ""
        '
        'btnPay
        '
        Me.btnPay.Location = New System.Drawing.Point(430, 314)
        Me.btnPay.Name = "btnPay"
        Me.btnPay.Size = New System.Drawing.Size(92, 32)
        Me.btnPay.TabIndex = 17
        Me.btnPay.Text = "Pay"
        Me.btnPay.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(52, 322)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(96, 17)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "Enter Money: "
        '
        'txtMoney
        '
        Me.txtMoney.Location = New System.Drawing.Point(154, 319)
        Me.txtMoney.Name = "txtMoney"
        Me.txtMoney.Size = New System.Drawing.Size(107, 22)
        Me.txtMoney.TabIndex = 19
        '
        'PayBill
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(765, 393)
        Me.Controls.Add(Me.txtMoney)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnPay)
        Me.Controls.Add(Me.richTxtDescrip)
        Me.Controls.Add(Me.txtTax)
        Me.Controls.Add(Me.txtGrand)
        Me.Controls.Add(Me.txtDate)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ComboBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "PayBill"
        Me.Text = "PayBill"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents ComboBox1 As ComboBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents txtDate As Label
    Friend WithEvents txtGrand As Label
    Friend WithEvents txtTax As Label
    Friend WithEvents richTxtDescrip As RichTextBox
    Friend WithEvents btnPay As Button
    Friend WithEvents Label3 As Label
    Friend WithEvents txtMoney As TextBox
End Class
