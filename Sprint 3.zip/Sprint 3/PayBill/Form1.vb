﻿Public Class PayBill
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged

        If ComboBox1.SelectedIndex = 0 Then
            richTxtDescrip.Text = "Flower Type         QTY        Unit Price       SubTotal" + Environment.NewLine +
                                  "=========================================" + Environment.NewLine +
                                  "Sun flower              1               RM 10             RM 10" + Environment.NewLine +
                                  "Scilla                        2              RM 15             RM 30"

            txtDate.Text = "22/6/2020"
            txtTax.Text = "$0"
            txtGrand.Text = "40"

        ElseIf ComboBox1.SelectedIndex = 1 Then
            richTxtDescrip.Text = "Flower Type         QTY        Unit Price       SubTotal" + Environment.NewLine +
                                  "=========================================" + Environment.NewLine +
                                  "Calla Lily                4               RM 10             RM 40" + Environment.NewLine +
                                  "Gaillardia               3               RM 30             RM 90 "

            txtDate.Text = " 22/7/2020"
            txtTax.Text = "$0"
            txtGrand.Text = "130"


        Else
            richTxtDescrip.Text = "Flower Type         QTY        Unit Price       SubTotal" + Environment.NewLine +
                                  "=========================================" + Environment.NewLine +
                                  "Jaborosa               2               RM 10             RM 20" + Environment.NewLine +
                                  "Orchid                     3               RM 20             RM 60 "

            txtDate.Text = " 22/8/2020"
            txtTax.Text = "$0"
            txtGrand.Text = "80"
        End If


    End Sub

    Private Sub PayBill_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
    End Sub

    Private Sub btnPay_Click(sender As Object, e As EventArgs) Handles btnPay.Click
        If ComboBox1.SelectedIndex = 0 Then
            If txtMoney.Text = txtGrand.Text Then
                MessageBox.Show("You can continue further order!", "Successful")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(0)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

            ElseIf (txtMoney.Text < txtGrand.Text) Or vbEmpty Then
                MessageBox.Show("Insufficient money!", "Error")
                txtMoney.Text = ""
            ElseIf txtMoney.Text > txtGrand.Text Then
                MessageBox.Show(" Please Get back your change!")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(0)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

                'ElseIf txtMoney.Text = " " Then
                '    MessageBox.Show("Please enter money!", "Error")

            End If

        ElseIf ComboBox1.SelectedIndex = 1 Then
            If txtMoney.Text = txtGrand.Text Then
                MessageBox.Show("You can continue further order!", "Successful")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(1)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

            ElseIf (txtMoney.Text < txtGrand.Text) Or vbEmpty Then
                MessageBox.Show("Insufficient money!", "Error")
                txtMoney.Text = ""
            ElseIf txtMoney.Text > txtGrand.Text Then
                MessageBox.Show(" Please Get back your change!")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(1)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

            End If

        ElseIf ComboBox1.SelectedIndex = 2 Then
            If txtMoney.Text = txtGrand.Text Then
                MessageBox.Show("You can continue further order!", "Successful")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(2)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

            ElseIf (txtMoney.Text < txtGrand.Text) Or vbEmpty Then
                MessageBox.Show("Insufficient money!", "Error")
                txtMoney.Text = ""
            ElseIf txtMoney.Text > txtGrand.Text Then
                MessageBox.Show(" Please Get back your change!")
                txtMoney.Text = ""

                ComboBox1.Items.RemoveAt(2)
                richTxtDescrip.Text = ""
                txtDate.Text = ""
                txtTax.Text = ""
                txtGrand.Text = ""

            End If
        End If

    End Sub
End Class
