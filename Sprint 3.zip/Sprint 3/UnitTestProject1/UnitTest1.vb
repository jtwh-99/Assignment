﻿Imports System.Text
Imports Microsoft.VisualStudio.TestTools.UnitTesting

<TestClass()> Public Class UnitTest1

    Public Function sum(a As Integer, b As Integer)
        Return a + b
    End Function

    <TestMethod()> Public Sub TestMethod1()
        Console.WriteLine("Hello")
        Assert.AreEqual(3, sum(1, 2))
    End Sub

End Class